import time,logging

from handler.config.config import ConfigClass
from handler.CDH.Cloudera import ClouderaHandler
from services.zookeeper import Zookeeper

LOG = logging.getLogger(__name__)

def main():
    Config=ConfigClass()
    username=Config.get("CDHDeployment.AUTHENTICATION.USERNAME")
    password=Config.get("CDHDeployment.AUTHENTICATION.PSSWORD")
    SSL=Config.get("CDHDeployment.SSL")
    Cloudera=ClouderaHandler(username=username,password=password,ssl=SSL)
    Cloudera.create_cluster()
    api,cluster=Cloudera.get_cluster()
    zookeeper=Zookeeper()
    zookeeper.deploy(cluster)

if __name__ == "__main__":
    main()