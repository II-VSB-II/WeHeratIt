import os
import time
from datetime import datetime
from handler.BLUEDATA.Bluedata import BlueDataHandler

class Zookeeper(BlueDataHandler):

    def __init__(self):
        self.ZOOKEEPER_SERVICE_NAME = "ZOOKEEPER"
        self.ZOOKEEPER_SERVICE_CONFIG = {'zookeeper_datadir_autocreate': 'true'}
        self.ZOOKEEPER_ROLE_CONFIG = {
            'quorumPort': 2888,
            'electionPort': 3888,
            'dataLogDir': '/var/lib/zookeeper',
            'dataDir': '/var/lib/zookeeper',
            'maxClientCnxns': '1024'}

    def deploy(self,cluster):
        zk = cluster.create_service(self.ZOOKEEPER_SERVICE_NAME, "ZOOKEEPER")
        zk.update_config(self.ZOOKEEPER_SERVICE_CONFIG)
        zk_hosts=BlueDataHandler.get_fqdn(role="zookeeper")
        for zk_host in zk_hosts:
                # Zookeeper IDs need to start from 1
            id=1
            zk_id = str(id)
            self.ZOOKEEPER_ROLE_CONFIG['serverId'] = zk_id
            role = zk.create_role(self.ZOOKEEPER_SERVICE_NAME + "-" + str(zk_id), "SERVER", zk_host)
            role.update_config(self.ZOOKEEPER_ROLE_CONFIG)
            id=+1

            # auto create data directories, hence not needed
            # zk.init_zookeeper()

        return zk
