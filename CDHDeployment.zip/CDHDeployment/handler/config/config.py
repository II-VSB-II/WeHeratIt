"""
Copyright (c) by SAN DATA SYSTEM, 2019. All rights reserved.
"""
import os
import datetime
import json
import shutil
import yaml
from cerberus import Validator
from handler.Exception import exceptions
from handler import constants


class ConfigClass():
    def __init__(self):
        """Return CDH configuration object.
        :raises: handler.Exceptions.ConfigException
        """
        self.config_file = constants.ROOT_PATH+'/config/'+constants.CONFIG_FILE
        self.schema_file = constants.ROOT_PATH + '/config/' + constants.CONFIG_SCHEMA_FILE

        self._config = self.validate_config(self.config_file,self.schema_file)

    def validate_config(self,config_file,schema_file):
        """Return validated CDH configuration object.
        :param config_file: filepath to configuration file
        :raises: handler.Exceptions.ConfigException
        """

        self.check_file_exists(config_file)
        self.check_file_exists(schema_file)
        config = self.parse_yaml_file(self.config_file)
        schema = self.parse_yaml_file(schema_file)
        return self._validate_config(config, schema)

    def check_file_exists(self,filepath):
        """
        Check if file exists, or raise exception.
        """
        if not os.path.exists(filepath):
            raise exceptions.ConfigException('error finding configuration file at {}'.format(filepath))

    def parse_yaml_file(self,filepath):
        """
        Parse yaml file into a dictionary, or raise exception.
        """
        with open(filepath, 'r') as f:
            try:
                return yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise exceptions.ConfigException('error reading configuration file at {}:\n{}'.format(filepath, str(e)))

    def _validate_config(self,config, schema):
        """
        Validate and normalize configurations, or raise exception.
        :param config: configuration in dictionary format
        :param schema: configuration schema in dictionary format
        """
        validator = Validator(schema)
        if not validator.validate(config):
            raise exceptions.ConfigException('error validating configurations:\n{}'.format(json.dumps(validator.errors, indent=4)))
        return validator.document




    def __eq__(self, obj):
        """
        Compare equality with another configuration object.
        """
        return self.to_dict() == obj.to_dict()

    def __getitem__(self, key):
        """
        Add support for accessing keys using dictionary brackets.
        """
        return self._config.get(key)

    def __setitem__(self, key, value):
        self._config[key] = value


    def __contains__(self, key):
        """
        Add support for checking whether key exists.
        """
        return key in self._config

    def to_dict(self):
        """
        Return config values in dictionary format.
        """
        return self._config

    def to_json(self):
        """
        Return config values in json format.
        """
        return json.dumps(self._config, indent=4, sort_keys=True)

    def to_yaml(self):
        """
        Return config values in yaml format.
        """
        return yaml.dump(self._config, default_flow_style=False)

    def get(self, key, default=None):
        """
        Return config value for config key(s).
        """
        try:
            return self._get(self._config, key)
        except (KeyError, TypeError):
            return default

    def _get(self, dct, key):
        """
        Recursive lookup of value for key in dictionary.

        :param key: nested keys in dot format
        """
        if '.' not in key:
            return dct[key]

        key, nested_key = key.split('.', 1)
        return self._get(dct[key], nested_key)

    def set(self, key, val, default=None):
        try:
            return self._set(self._config, key, val)
        except (KeyError, TypeError):
            return default

    def _set(self, dct, key, val):
        """
        Recursive lookup of value for key in dictionary.

        :param key: nested keys in dot format

        """
        if '.' not in key:
            dct[key]=val
        for k in key[:-1]:
            dct = dct[k]
        dct[key[-1]] = val
