import os
from handler.BLUEDATA.Bluedata import BlueDataHandler
import logging
from subprocess import Popen, PIPE, STDOUT
LOG = logging.getLogger(__name__)

class CMConfig(BlueDataHandler):

    def get_cm_config(self):
        CM_CONFIG = {
            'MISSED_HB_BAD' : 1000,
            'MISSED_HB_CONCERNING' : 1000,
            'TSQUERY_STREAMS_LIMIT' : 1000,
            'REMOTE_PARCEL_REPO_URLS' : self.get_config_metadata(name="cdh_parcel_repo")
        }
        return CM_CONFIG

    ### Management Services ###
    # If using the embedded postgresql database, the database passwords can be found in /etc/cloudera-scm-server/db.mgmt.properties.
    # The values change every time the cloudera-scm-server-db process is restarted.
    def get_mgmt_config(self):
        MGMT_SERVICENAME = "MGMT"
        MGMT_SERVICE_CONFIG = {
            'zookeeper_datadir_autocreate': 'false',
        }
        MGMT_ROLE_CONFIG = {
            'quorumPort': 2888,
        }
        return MGMT_SERVICENAME, MGMT_SERVICE_CONFIG, MGMT_ROLE_CONFIG

    def get_all_role(self):
        return ["ACTIVITYMONITOR","ALERTPUBLISHER","EVENTSERVER","HOSTMONITOR","SERVICEMONITOR"] #,"NAVIGATOR","NAVIGATORMETADATASERVER","REPORTMANAGER"]

    def get_role_config(self,role):

        AMON_ROLE_CONFIG = {
            'firehose_database_host': self.get_fqdn(),
            'firehose_database_user': 'amon',
            'firehose_database_password': 'amon_password',
            'firehose_database_type': 'mysql',
            'firehose_database_name': 'amon',
            'firehose_heapsize': '268435456',
        }

        APUB_ROLE_CONFIG = {}

        ESERV_ROLE_CONFIG = {
            'event_server_heapsize': '268435456'
        }

        HMON_ROLE_CONFIG = {
            'firehose_non_java_memory_bytes': '6442450944'
        }

        SMON_ROLE_CONFIG = {
            'firehose_non_java_memory_bytes': '6442450944'
        }
        NAV_ROLE_CONFIG = {
            'navigator_database_host': self.get_fqdn() + ":7432",
            'navigator_database_user': 'nav',
            'navigator_database_password': 'nav_password',
            'navigator_database_type': 'mysql',
            'navigator_database_name': 'nav',
            'navigator_heapsize': '268435456',
        }

        RMAN_ROLE_CONFIG = {
            'headlamp_database_host': self.get_fqdn() + ":7432",
            'headlamp_database_user': 'rman',
            'headlamp_database_password': 'rman_password',
            'headlamp_database_type': 'mysql',
            'headlamp_database_name': 'rman',
            'headlamp_heapsize': '215964392',
        }
        roleconfig={"ACTIVITYMONITOR":AMON_ROLE_CONFIG,"ALERTPUBLISHER":APUB_ROLE_CONFIG,"EVENTSERVER":ESERV_ROLE_CONFIG,"HOSTMONITOR":HMON_ROLE_CONFIG,"SERVICEMONITOR":SMON_ROLE_CONFIG}

        return roleconfig[role]



    def get_process_swap_alert_config(self):
        PROCESS_SWAP_ALERT_OFF = {'process_swap_memory_thresholds': '{"warning":"never", "critical":"never"}'}
        return PROCESS_SWAP_ALERT_OFF

    def get_host_swap_alert_config(self):
        HOST_SWAP_ALERT_OFF = {"host_memswap_thresholds": '{"warning":"never", "critical":"never"}'}
        return HOST_SWAP_ALERT_OFF

    def get_java_path(self):
        HOST_JAVA_HOME = {"java_home": '/opt/jdk1.8.0_131'}
        return HOST_JAVA_HOME

    def popen_util(COMMAND, OPERATION_NAME):
        LOG.info("Executing command: " + str(COMMAND))
        sp = Popen(COMMAND, shell=True, stdin=PIPE, stdout=PIPE,
                   stderr=STDOUT, close_fds=True)
        sp_out = sp.communicate()
        if sp.returncode == 0:
            LOG.info("Successfully completed " + OPERATION_NAME)
        else:
            LOG.error("Failed to " + OPERATION_NAME + " due to \n" + str(sp_out))






