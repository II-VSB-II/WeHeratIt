import socket, sys, time, os
import logging, traceback, uuid

from cm_api.api_client import ApiResource, ApiException
from cm_api.endpoints.services import ApiService
from cm_api.endpoints.services import ApiServiceSetupInfo
from optparse import OptionParser
from bd_vlib import *
from bdmacro import *
from math import log as ln
from handler.config import config
from handler.BLUEDATA.Bluedata import BlueDataHandler
from handler.CDH.CDHUtility import CMConfig
LOG = logging.getLogger(__name__)

class ClouderaHandler(BlueDataHandler,CMConfig):
    def __init__(self, username, password, ssl=False):
        self.cloudera_host=self.get_fqdn()
        self.username=username
        self.password=password
        if ssl:
            self.port=7183
        else:
            self.port=7180

    def create_cluster(self):
        api = ApiResource(self.cloudera_host, username=self.username, password=self.password)
        while True:
            current_all_hosts = map(lambda x: x.hostname, api.get_all_hosts())
            LOG.info("Currently registered hosts with CM:" + str(current_all_hosts))
            if all(x in current_all_hosts for x in self.get_allfqdn()):
                break
            LOG.info("waiting for new nodes to register with cloudera manager")
            time.sleep(10)
        manager = api.get_cloudera_manager()
        manager.update_config(self.get_cm_config())
        cluster = api.create_cluster(self.get_cluster_name(), self.get_config_metadata(name="cdh_major_version"),
                                     self.get_config_metadata(name="cdh_full_version"))
        cluster.add_hosts(self.get_allfqdn())

        self.hosts_swap_alert_off(api)

        ##Set java home
        self.hosts_set_javahome(api)

        ##Add Spark parcel
        self.add_spark2_repo(api)

        self.activate_parcel(cluster,name="CDH",version=self.get_config_metadata(name="cdh_parcel_version"))
        self.activate_parcel(cluster,name="SPARK2",version=self.get_config_metadata(name="spark2_parcel_version"))
        BDVLIB_TokenWake(self.get_config_metadata(name="cdh_parcel_version"))
        BDVLIB_TokenWake(self.get_config_metadata(name="spark2_parcel_version"))

        self.deploy_management(manager)


    def activate_parcel(self,cluster,name,version):
        ## after we create a cluster, parcels may not show up immediately
        ## retry the operation to get parcels. We never timeout here.
        retry_count = 1
        while len(cluster.get_all_parcels()) == 0:
            LOG.info("Retrying parcel get operation")
            time.sleep(10)
        p = cluster.get_parcel(name, version)
        if p.stage != "DOWNLOADED" and p.stage != "ACTIVATED":
            raise Exception("parcels should have been downloaded in the image")
        p.start_distribution()
        while True:
            p = cluster.get_parcel(name, version)
            state = p.state
            if p.stage == "DISTRIBUTED" and state.progress == state.totalProgress:
                break
            if p.state.errors:
                raise Exception(str(p.state.errors))
            LOG.info(p)
            time.sleep(10)
        p.activate()
        while True:
            p = cluster.get_parcel(name, version)
            state = p.state
            if p.stage == "ACTIVATED" and state.progress == state.totalProgress:
                break
            if p.state.errors:
                raise Exception(str(p.state.errors))
            LOG.info(p)
            time.sleep(10)


    def hosts_swap_alert_off(self,api):
        Hosts = api.get_all_hosts()
        for Host in Hosts:
            try:
                Host.update_config(self.get_host_swap_alert_config())
            except:
                LOG.warn("Exception turning off swap for host " + str(Host))

    def hosts_set_javahome(self,api):
        Hosts = api.get_all_hosts()
        for Host in Hosts:
            try:
                Host.update_config(self.get_java_path())
            except:
                LOG.warn("Exception setting java home for host" + str(Host))

    def service_swap_alert_off(self,Service):
        Roles = Service.get_all_roles()
        for Role in Roles:
            try:
                if Role.type != 'GATEWAY':
                    Role.update_config(self.get_process_swap_alert_config())
                else:
                    # gateway roles are not processes
                    pass
            except:
                LOG.warn("Exception turning off swap for role " + str(Role))

    def add_spark2_repo(self, api):
        ## Add Spark2 URL
        cm = api.get_cloudera_manager()
        config = cm.get_config(view='summary')
        parcel_urls = config.get("REMOTE_PARCEL_REPO_URLS", "").split(",")
        SPARK2_PARCEL_REPO=self.get_config_metadata(name="spark2_parcel_version")
        if SPARK2_PARCEL_REPO in parcel_urls:
            # already there, skip
            LOG.info("SPARK2 repo url already included")
        else:
            parcel_urls.append(SPARK2_PARCEL_REPO)
            config["REMOTE_PARCEL_REPO_URLS"] = ",".join(parcel_urls)
            cm.update_config(config)
            # wait to make sure parcels are refreshed
            time.sleep(10)
            LOG.info("Added SPARK2 repo url")

    def deploy_management(self,manager):
        name,service_config,role_config=self.get_mgmt_config()
        mgmt = manager.create_mgmt_service(ApiServiceSetupInfo())

        for role in self.get_all_role():
            mgmt.create_role(role + "-1", role, self.cloudera_host)

        LOG.info("Copy Bluedata Jar..")
        shell_command = ['sudo cp -f /opt/bluedata/bluedata-dtap.jar /usr/share/cmf/lib']
        self.popen_util(shell_command, "copy dtap jar to cm shared libs path")

        for group in mgmt.get_all_role_config_groups():
            if group.roleType == "ACTIVITYMONITOR":
                group.update_config(self.get_roles_config(role="ACTIVITYMONITOR"))
            elif group.roleType == "ALERTPUBLISHER":
                group.update_config(self.get_roles_config(role="ALERTPUBLISHER"))
            elif group.roleType == "EVENTSERVER":
                group.update_config(self.get_roles_config(role="EVENTSERVER"))
            elif group.roleType == "HOSTMONITOR":
                group.update_config(self.get_roles_config(role="HOSTMONITOR"))
            elif group.roleType == "SERVICEMONITOR":
                group.update_config(self.get_roles_config(role="SERVICEMONITOR"))

        mgmt.start().wait()
        self.service_swap_alert_off(mgmt)
        LOG.info("Deployed CM management service " + "Management Service "+ " to run on hosts:" + self.cloudera_host)

    def get_cluster(self):
        # connect to cloudera manager
        api = ApiResource(self, username=self.username, password=self.password)
        # Take care of the case where cluster name has changed
        # Hopefully users wouldn't use this CM to deploy another cluster manually
        return (api, api.get_cluster(api.get_all_clusters()[0].name))



    def enable_kerberos(self):
        pass



