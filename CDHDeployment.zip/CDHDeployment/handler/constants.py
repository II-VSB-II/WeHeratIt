"""
Copyright (c) by SAN DATA SYSTEM, 2019. All rights reserved.
"""
# pylint: disable=line-too-long
import os
import sys
import socket

# ******************************************** #
# Application directories                      #
# ******************************************** #

ROOT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(sys.executable)))
PACKAGE_PATH = os.path.dirname(os.path.abspath(__file__))

CONFIG_FILE="CDH.yml"
CONFIG_SCHEMA_FILE="SCHEMA.yml"
LOG_FILE="deployment.log"