import os
import logging
LOG = logging.getLogger(__name__)

class BlueDataHandler():
    def __init__(self):
        self.ConfigMeta = BDVLIB_ConfigMetadata()

    def get_fqdn(self,role=None):
        if role:
            return self.ConfigMeta.getWithTokens(["node", "fqdn"])
        else:
            return self.ConfigMeta.getWithTokens(['nodegroups', self.get_nodegroup_id(), 'roles', role, 'fqdns'])

    def get_allfqdn(self):
        return self.ConfigMeta.getLocalGroupHosts().sort()

    def get_distro_id(self):
        return self.ConfigMeta.getWithTokens(["node", "distro_id"])

    def get_nodegroup_id(self):
        return self.ConfigMeta.getWithTokens(["node", "nodegroup_id"])

    def get_cluster_id(self):
        self.ConfigMeta.getWithTokens(["cluster", "id"])

    def get_cluster_name(self):
        self.ConfigMeta.getWithTokens(["cluster", "name"])

    def get_config_choice(self,name=None):
        return self.ConfigMeta.getWithTokens(["cluster","config_choice_selections", self.get_nodegroup_id(), name])

    def get_config_metadata(self,name=None):
        return self.ConfigMeta.getWithTokens(["cluster", "config_metadata", self.get_nodegroup_id(), name])

    def get_hosts_for_service(self,serviceKey, returnSingle=False):
        keylist = self.ConfigMeta.searchForToken(serviceKey, "fqdns")
        valuelist = []
        for key in keylist:
            valuelist.extend(self.ConfigMeta.getWithTokens(key))
        if returnSingle:
            if len(valuelist) > 1:
                LOG.warn(
                    "returnSingle arg for get_hosts_for_service is True, but > 1 service nodes for key " + str(
                        serviceKey))
            elif len(valuelist) > 0:
                return valuelist[0]
        return valuelist


