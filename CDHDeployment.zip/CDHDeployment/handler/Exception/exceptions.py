"""
Copyright (c) by Hitachi Vantara, 2018. All rights reserved.
"""


class CDHException(Exception):
    """Generic exception for CDH errors."""
    pass


class ConfigException(Exception):
    """CDH configuration exception"""
    pass

class BLUEDATAException(Exception):
    """ Generic exception for BLUEDATA exception"""
    pass